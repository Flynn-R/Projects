#include <windows.h>
#include "consts.h"

int main()
{
    setlocale(LC_ALL, "Russian");
    SetConsoleOutputCP(1251);
    SetConsoleCP(1251);

    std::wcout << hello;
    do
    {
        std::wstring input;
        getline(std::wcin, input);
        system("cls");
        loop(input);
    } while (true);
}