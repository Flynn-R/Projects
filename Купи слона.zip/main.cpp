#include <windows.h>
#include "consts.h"

void main()
{
    setlocale(LC_ALL, "Russian");

    std::wcout << hello;
    std::wstring input;
    do
    {
        input.clear();
        getline(std::wcin, input);
        system("cls");
        loop(input);
    } while (true);
}