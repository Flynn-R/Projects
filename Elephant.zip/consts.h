#pragma once
#include <iostream>

const wchar_t* everybodySays = L"Все говорят \"";
const wchar_t* buy = L"\", а ты возьми и купи слона!\n";

void loop(const char* input)
{
    std::wcout << everybodySays << input << buy;
}