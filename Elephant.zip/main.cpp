#include <windows.h>
#include "consts.h"

int main(int n, const char* args[])
{
    setlocale(LC_ALL, "Russian");
    SetConsoleOutputCP(1251);
    SetConsoleCP(1251);

    loop(args[1]);
    system("pause");

    return 0;
}